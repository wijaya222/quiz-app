Cara Menjalankan dan Deploy Aplikasi Quiz ke GitHub Pages:

1. Buka terminal dan arahkan ke folder quiz-app/
2. Jalankan:
   npm install
3. Untuk menjalankan lokal:
   npm start
4. Untuk deploy ke GitHub Pages:
   npm run deploy

Pastikan kamu sudah login GitHub dan punya repository bernama: quiz-app
URL hasil akhir akan tersedia di:
https://wijaya222.github.io/quiz-app

Kamu bisa pakai URL ini di MIT App Inventor sebagai WebViewer HomeUrl.
