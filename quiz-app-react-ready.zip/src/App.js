import React, { useState, useEffect } from "react";

const allQuestions = [
  {
    question: "Apa ibu kota Indonesia?",
    options: ["Bandung", "Jakarta", "Surabaya", "Medan"],
    answer: "Jakarta",
  },
];

function getRandomQuestions(array, num) {
  const shuffled = [...array].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, num);
}

const Card = ({ children }) => (
  <div style={{ border: '1px solid #ccc', borderRadius: 10, marginBottom: 10 }}>
    {children}
  </div>
);
const CardContent = ({ children }) => (
  <div style={{ padding: 16 }}>{children}</div>
);
const Button = ({ children, ...props }) => (
  <button style={{ padding: 10, margin: 5, backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: 4 }} {...props}>
    {children}
  </button>
);

function QuizApp() {
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);

  useEffect(() => {
    setQuestions(getRandomQuestions(allQuestions, 10));
  }, []);

  useEffect(() => {
    if (!quizFinished && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setQuizFinished(true);
    }
  }, [timeLeft, quizFinished]);

  const handleAnswer = (option) => {
    const correct = questions[current].answer === option;
    if (correct) setScore(prev => prev + 1);

    const newSelected = [...selectedAnswers, { ...questions[current], selected: option }];
    setSelectedAnswers(newSelected);

    if (current + 1 < questions.length) {
      setCurrent(prev => prev + 1);
    } else {
      setQuizFinished(true);
    }
  };

  if (quizFinished) {
    return (
      <div style={{ padding: 20, maxWidth: 600, margin: 'auto' }}>
        <h1>Skor: {score}/10</h1>
        {selectedAnswers.map((q, idx) => (
          <Card key={idx}>
            <CardContent>
              <p><strong>{idx + 1}. {q.question}</strong></p>
              <p style={{ color: q.selected === q.answer ? 'green' : 'red' }}>Jawaban Anda: {q.selected}</p>
              <p style={{ color: 'blue' }}>Jawaban Benar: {q.answer}</p>
            </CardContent>
          </Card>
        ))}
        <div style={{ textAlign: 'center' }}>
          <Button onClick={() => window.location.reload()}>Main Lagi</Button>
        </div>
      </div>
    );
  }

  if (questions.length === 0) return <div style={{ padding: 20 }}>Memuat pertanyaan...</div>;

  const q = questions[current];

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2>Pertanyaan {current + 1} dari 10</h2>
        <div style={{ color: 'red' }}>Sisa Waktu: {timeLeft} detik</div>
      </div>
      <Card>
        <CardContent>
          <p><strong>{q.question}</strong></p>
          {q.options.map((option, idx) => (
            <Button key={idx} onClick={() => handleAnswer(option)}>{option}</Button>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

export default QuizApp;
